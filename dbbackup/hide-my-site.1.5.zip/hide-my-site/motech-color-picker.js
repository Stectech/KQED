jQuery(document).ready(function($){
    jQuery('.motech-color-field').wpColorPicker();
});